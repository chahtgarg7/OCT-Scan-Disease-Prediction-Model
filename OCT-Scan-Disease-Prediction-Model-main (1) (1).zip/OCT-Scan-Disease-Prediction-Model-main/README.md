# OCT Scan Disease Prediction Model

A deep learning–based project designed to detect and classify retinal diseases using **Optical Coherence Tomography (OCT)** scan images. The system leverages convolutional neural networks to analyze retinal layers and assist in early diagnosis of eye diseases.

> This project aims to support medical practitioners and researchers by providing an automated, efficient, and scalable diagnostic aid.

---

## Features

- Automated disease prediction from OCT scan images
- Deep learning–based image classification
- Model training and evaluation notebooks
- Prediction interface using a web application
- Recommendation module for disease guidance
- Training history visualization and analysis

---

## Repository Structure

```
OCT-Scan-Disease-Prediction-Model/
│
├── Training_Model.ipynb       # Model training notebook
├── Model_prediction.ipynb     # Prediction and testing notebook
├── Training_history.pkl       # Stored training metrics/history
├── app.py                     # Web application script
├── recommendation.py          # Disease recommendation logic
├── requirements.txt           # Project dependencies
└── LICENSE                    # MIT License
```

---

## Technologies Used

| Technology | Purpose |
|---|---|
| Python | Core programming language |
| TensorFlow / Keras | Deep learning framework |
| NumPy | Numerical computations |
| Pandas | Data manipulation |
| Matplotlib | Visualization |
| OpenCV | Image processing |
| Flask | Web app deployment |
| Jupyter Notebook | Model development & experimentation |

---

## Dataset

The model is trained on OCT retinal scan images categorized into multiple disease classes:

| Class | Description |
|---|---|
| **CNV** | Choroidal Neovascularization |
| **DME** | Diabetic Macular Edema |
| **Drusen** | Early AMD indicator |
| **Normal** | Healthy retina |

> **Note:** Ensure the dataset is placed in the correct directory structure before training.

---

## Installation

**1. Clone the repository:**

```bash
git clone https://github.com/BiswarupMukherjee2005/OCT-Scan-Disease-Prediction-Model.git
cd OCT-Scan-Disease-Prediction-Model
```

**2. Install dependencies:**

```bash
pip install -r requirements.txt
```

---

## Model Training

To train the model, open and run:

```
Training_Model.ipynb
```

This notebook includes:
- Data preprocessing
- Image augmentation
- CNN model architecture
- Training and validation
- Performance visualization

---

## Prediction

To test predictions, open and run:

```
Model_prediction.ipynb
```

You can:
- Load the trained model
- Input OCT images
- Generate disease predictions

---

## Running the Web Application

Launch the web interface with:

```bash
python app.py
```

Then open your browser and navigate to:

```
http://127.0.0.1:5000/
```

Upload an OCT image to receive predictions and recommendations.

---

## Recommendation System

The `recommendation.py` module provides:

- Basic disease information
- Preventive measures
- Medical guidance suggestions

This enhances the diagnostic output with actionable insights.

---

## Results

The model achieves strong classification performance on validation data, with training history saved in `Training_history.pkl`.

**Metrics tracked:**

| Metric | Description |
|---|---|
| Accuracy | Training accuracy per epoch |
| Loss | Training loss per epoch |
| Validation Accuracy | Accuracy on validation set |
| Validation Loss | Loss on validation set |

---

## Future Improvements

- [ ] Integration with real-time hospital databases
- [ ] Deployment on cloud platforms
- [ ] Mobile application support
- [ ] Explainable AI visualizations (Grad-CAM)
- [ ] Multi-disease severity grading

---

## License

This project is licensed under the **MIT License**. See the [LICENSE](LICENSE) file for details.

---

## Author

**Biswarup Mukherjee**

---

<div align="center">
  <i>If you find this project useful, please consider giving it a star</i>
</div>
